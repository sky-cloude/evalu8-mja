from transformers import AutoTokenizer, AutoModelForSequenceClassification

# Model name from Hugging Face
model_name = "cardiffnlp/twitter-xlm-roberta-base-sentiment"

# Directory to save the model and tokenizer
local_model_dir = "C:\\xampp\\htdocs\\CAPSTONE 2 - SYSTEM\\RoBERTa model"

# Download and save the tokenizer
print("Downloading and saving tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(model_name)
tokenizer.save_pretrained(local_model_dir)

# Download and save the model
print("Downloading and saving model...")
model = AutoModelForSequenceClassification.from_pretrained(model_name)
model.save_pretrained(local_model_dir)

print(f"Model and tokenizer have been saved locally in '{local_model_dir}'")