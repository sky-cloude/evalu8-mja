<?php
session_start(); // Start the session at the very beginning
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Batch Print Staff DTR</title>
    <?php include('../header.php'); ?>
    <link rel="icon" type="image/png" href="../Logo/mja-logo.png">
    <link rel="stylesheet" href="../css/sidebar.css" />
    <link rel="stylesheet" href="../css/admin-elements.css" />
    <style>
        /* Existing styles */
        .breadcrumbs-container {
            margin-top: 3%;
            margin-left: 0%;
            margin-bottom: 1.5%;
            padding-top: 2%;
            width: 98%;
        }
        .breadcrumbs {
            display: flex;
            align-items: center;
            height: 40px;
            background-color: #ffffff;
            border: 1px solid #ddd;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            padding: 8px 15px;
        }
        .breadcrumb-item a {
            text-decoration: none;
            color: #6c757d;
        }
        .breadcrumb-item.active {
            color: #6c757d;
        }

        /* Responsive Breadcrumbs */
        @media (max-width: 767px) { 
            .breadcrumbs-container {
                padding-top: 1%;
                margin-top: 15%;
                margin-bottom: 5%;
            }
            .breadcrumbs {
                flex-wrap: wrap;
                font-size: 0.85rem;
                padding: 5px 10px;
                height: auto;
            }
            .breadcrumb-item a, .breadcrumb-item.active {
                font-size: 0.8rem;
                padding: 0;
                margin-right: 5px;
            }
            .breadcrumb-item i {
                font-size: 0.9rem;
                margin-right: 3px;
            }
            .breadcrumb-item:not(:last-child)::after {
                content: '>';
                padding: 0 4px;
            }
        }

        .btn-back {
            background: none;
            border: none;
            padding: 0;
            color: #281313;
            margin-right: 35px;
        }

        .btn-back i {
            font-size: 2.5rem; /* Adjust the size of the icon */
        }

        .btn-back:hover {
            color: #facc15;
        }

        /* Month Navigation and Print Button Styles */
        .month-navigation {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .month-navigation i {
            font-size: 2rem;
            cursor: pointer;
            color: #281313;
        }

        .month-navigation i:hover {
            color: #facc15;
        }

        .print-dtr-btn {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        /* Wider Batch Print DTR Button */
        .btn-print {
            background-color: #281313;
            color: white;
            font-size: 1rem;
            padding: 12px 50px;
            border: none;
            border-radius: 50px;
            width: 250px;
            text-align: center;
            cursor: not-allowed;
            opacity: 0.6;
        }

        .btn-print.enabled {
            cursor: pointer;
            opacity: 1;
        }

        .btn-print:hover {
            background-color: #facc15;
            color: #281313;
        }

        /* Table Styles */
        .staff-table-container {
            max-width: 80%;
            margin: auto;
        }

        .staff-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 1rem;
            margin-top: 20px;
        }

        .staff-table th, .staff-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        .staff-table th {
            background-color: #f3f3f3;
            font-weight: bold;
        }

        .staff-table td {
            vertical-align: middle;
        }

        .no-result {
            text-align: center;
            font-style: italic;
            color: #6c757d;
        }

        .checkbox-cell {
            width: 50px;
            text-align: center;
        }

        /* Container width for small screens */
        @media (max-width: 767px) {
            .container {
                max-width: 95%;
                margin: auto;
            }
        }
    </style>
</head>

<body>
    <?php 
    include('../db_conn.php');
    include('navigation.php'); 

    // Get the current month and year
    $currentMonth = isset($_GET['month']) ? intval($_GET['month']) : date("m");
    $currentYear = isset($_GET['year']) ? intval($_GET['year']) : date("Y");

    // Query to get staff data ordered by role and last name
    $query = "SELECT staff_id, lastName, firstName, middleName, staff_role FROM staff_account ORDER BY staff_role ASC, lastName ASC";
    $result = mysqli_query($conn, $query);

    // Fetch admin's full name based on $_SESSION['user_id']
    $adminFullName = '';
    if (isset($_SESSION['user_id'])) {
        $admin_id = $_SESSION['user_id'];
        $queryAdmin = "SELECT firstName, middleName, lastName FROM admin_account WHERE admin_id = ?";
        $stmt = $conn->prepare($queryAdmin);
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $stmt->bind_result($adminFirstName, $adminMiddleName, $adminLastName);
        $stmt->fetch();
        $stmt->close();

        $adminMiddleInitial = !empty($adminMiddleName) ? ' ' . substr($adminMiddleName, 0, 1) . '.' : '';
        $adminFullName = $adminFirstName . $adminMiddleInitial . ' ' . $adminLastName;
    }
    ?>

    <!-- Breadcrumbs -->
    <div class="breadcrumbs-container">
        <nav aria-label="breadcrumb" class="breadcrumbs ms-4 bg-white border shadow rounded py-2 px-3">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="admin-dashboard.php" class="text-muted text-decoration-none">
                        <i class="fa-solid fa-house"></i> Home
                    </a>
                </li>
                <li class="breadcrumb-item">
                    <a href="staff-dtr.php" class="text-muted text-decoration-none">Staff DTR</a>
                </li>
                <li class="breadcrumb-item active text-muted" aria-current="page">Batch Print Staff DTR</li>
            </ol>
        </nav>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-3 ms-5">
        <p class="classTitle fs-4 fw-bold mb-2">Batch Print Staff DTR</p>
        <a href="staff-dtr.php" class="btn btn-back">
            <i class="fa-solid fa-circle-chevron-left"></i>
        </a>
    </div>
    <div class="mx-auto mb-4" style="height: 2px; background-color: #facc15; width:95%;"></div>

    <div class="container bg-white rounded border shadow mb-5 p-4">
        <!-- Month Navigation -->
        <div class="month-navigation">
            <i class="bi bi-caret-left-square-fill" id="prevMonth"></i>
            <span class="fs-4 fw-bold" id="monthDisplay"><?= date("F Y", strtotime("$currentYear-$currentMonth-01")); ?></span>
            <i class="bi bi-caret-right-square-fill" id="nextMonth"></i>
        </div>

        <!-- Print Button -->
        <div class="print-dtr-btn">
            <button class="btn-print" id="batchPrintBtn" disabled>
                <i class="fa-solid fa-print me-2"></i>Batch Print DTR
            </button>
        </div>

        <!-- Staff List Table -->
        <div class="staff-table-container mb-5">
            <table class="staff-table" id="staffTable">
                <thead>
                    <tr>
                        <th class="checkbox-cell"><input type="checkbox" id="selectAll"></th>
                        <th>Staff Name</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody id="staffTableBody">
                    <?php 
                    if ($result && mysqli_num_rows($result) > 0) {
                        $index = 1;
                        while ($row = mysqli_fetch_assoc($result)) {
                            $fullName = $row['firstName'] . ' ' . $row['lastName'];
                            $staff_role = $row['staff_role'];
                            echo "<tr data-role='{$staff_role}' data-name='{$fullName}'>
                                    <td class='checkbox-cell'><input type='checkbox' class='row-checkbox' name='selected[]' value='{$row['staff_id']}'></td>
                                    <td>{$index}. {$fullName}</td>
                                    <td>{$staff_role}</td>
                                  </tr>";
                            $index++;
                        }
                    } else {
                        echo "<tr class='no-result-row'><td colspan='3' class='no-result'>No Result</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include('footer.php'); ?>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const staffTableBody = document.getElementById("staffTableBody");
            const selectAllCheckbox = document.getElementById("selectAll");
            const batchPrintBtn = document.getElementById("batchPrintBtn");
            const monthDisplay = document.getElementById("monthDisplay");
            const prevMonthBtn = document.getElementById("prevMonth");
            const nextMonthBtn = document.getElementById("nextMonth");

            let currentDate = new Date("<?= $currentYear; ?>", "<?= $currentMonth - 1; ?>");

            // Function to update month display
            function updateMonthDisplay() {
                monthDisplay.textContent = currentDate.toLocaleDateString("en-US", { month: "long", year: "numeric" });
            }

            // Event listener for previous month button
            prevMonthBtn.addEventListener("click", function () {
                currentDate.setMonth(currentDate.getMonth() - 1);
                updateMonthDisplay();
                // Reload the page with new month and year
                const newMonth = currentDate.getMonth() + 1;
                const newYear = currentDate.getFullYear();
                window.location.href = `?month=${newMonth}&year=${newYear}`;
            });

            // Event listener for next month button
            nextMonthBtn.addEventListener("click", function () {
                currentDate.setMonth(currentDate.getMonth() + 1);
                updateMonthDisplay();
                // Reload the page with new month and year
                const newMonth = currentDate.getMonth() + 1;
                const newYear = currentDate.getFullYear();
                window.location.href = `?month=${newMonth}&year=${newYear}`;
            });

            // Initial display of current month
            updateMonthDisplay();

            // Toggle batch print button state
            function toggleBatchPrintButton() {
                const checkedRows = staffTableBody.querySelectorAll("input.row-checkbox:checked");
                batchPrintBtn.disabled = checkedRows.length === 0;
                batchPrintBtn.classList.toggle("enabled", checkedRows.length > 0);
            }

            // Select All functionality
            selectAllCheckbox.addEventListener("change", function () {
                const checkboxes = staffTableBody.querySelectorAll("input.row-checkbox");
                checkboxes.forEach(checkbox => checkbox.checked = selectAllCheckbox.checked);
                toggleBatchPrintButton();
            });

            // Update button status when individual row checkboxes are clicked
            staffTableBody.addEventListener("change", function(event) {
                if (event.target.classList.contains("row-checkbox")) {
                    toggleBatchPrintButton();
                }
            });

            // Batch Print DTR Functionality
            batchPrintBtn.addEventListener("click", function () {
                const checkedBoxes = staffTableBody.querySelectorAll("input.row-checkbox:checked");
                if (checkedBoxes.length === 0) return;

                const staffIds = Array.from(checkedBoxes).map(checkbox => checkbox.value);
                const month = currentDate.getMonth() + 1;
                const year = currentDate.getFullYear();

                // Send AJAX request to get the DTR data
                fetch('actions/batch-print-dtr-staff.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        staffIds: staffIds,
                        month: month,
                        year: year
                    })
                })
                .then(response => response.text())
                .then(data => {
                    // Open a new window and print the content
                    const printWindow = window.open('', '_blank', 'width=800,height=600');
                    printWindow.document.write(data);
                    printWindow.document.close();
                    printWindow.focus();
                    printWindow.print();
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            });
        });
    </script>
</body>
</html>
